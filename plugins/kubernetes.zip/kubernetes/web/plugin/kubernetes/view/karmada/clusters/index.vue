<template>
<div>
  clusters
</div>
</template>

<script>
export default {
  name: "index.vue"
}
</script>

<style scoped>

</style>
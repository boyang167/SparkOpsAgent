<template>
  <div>
    <el-table
      ref="multipleTable"
      :data="tableData"
      style="width: 100%"
      tooltip-effect="dark"
      row-key="ID"
    >
      <el-table-column
        type="selection"
        width="55"
      />
      <el-table-column
        align="left"
        label="名称"
        prop="name"
      >
        <template #default="scope">
          <div
            v-if="scope.row.metadata.name !== 'system' "
            slot="content"
          >
            <span
              class="operate-span-primary"
              @click="handleDetail(scope.row)"
            >{{ scope.row.metadata.name }}</span>
            <el-tooltip placement="top">
              <template #content>
                <div
                  v-for="(v,k, i) in scope.row.metadata.annotations"
                  slot="content"
                  :key="i"
                >
                  <span> {{ k }}: {{ v }}</span>
                </div>
              </template>
              <el-button
                size="small"
                type="primary"
                link
                icon="PriceTag"
              />
            </el-tooltip>
          </div>
        </template>
      </el-table-column>
      <el-table-column
          label="命名空间"
          min-width="70"
          prop="namespace"
      >
        <template #default="scope">
          {{ scope.row.metadata.namespace}}
        </template>
      </el-table-column>
      <el-table-column
        align="left"
        label="交付环境"
        prop="name"
      >
        <template #default="scope">
          <span> {{ targetdeduplication(scope.row.spec.policies) }}</span>
        </template>
      </el-table-column>
      <el-table-column
        label="创建时间"
        min-width="70"
        prop="createTime"
      >
        <template #default="scope">
          {{ formatTimeToStr(scope.row.metadata.creationTimestamp) }}
        </template>
      </el-table-column>
      <el-table-column
        align="left"
        label="操作"
      >
        <template #default="scope">
          <el-button
            size="small"
            type="primary"
            link
            icon="edit"
            @click="handleUpdate(scope.row)"
          >编辑</el-button>
          <el-popover
            v-model="scope.row.visible"
            placement="top"
          >
            <p>确定要删除吗？</p>
            <div style="text-align: right; margin-top: 8px;">
              <el-button
                size="small"
                type="primary"
                link
                @click="scope.row.visible = false"
              >取消</el-button>
              <el-button
                type="primary"
                size="small"
                @click="handleDelete(scope.row)"
              >确定</el-button>
            </div>
            <template #reference>
              <el-button
                type="primary"
                link
                icon="delete"
                size="small"
                @click="scope.row.visible = true"
              >删除</el-button>
            </template>
          </el-popover>
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>

<script>
export default {
  name: 'TableBlock',
  emits: {
    update: () => {
      return true
    },
    search: () => {
      return true
    },
    detail: () => {
      return true
    },
    delete: (value) => {
      if (value.length === 1) {
        return true
      } else {
        return false
      }
    },
  }
}
</script>
<script setup>
import { formatTimeToStr } from '@/plugin/kubernetes/utils/date'

const emit = defineEmits(['update', 'delete', 'search', 'detail'])
defineProps({
  tableData: {
    default: function() {
      return []
    },
    type: Array
  },
})

// 更新
const handleUpdate = (value) => {
  emit('update', value)
}

// 删除
const handleDelete = (value) => {
  emit('delete', value)
}

// 详情
const handleDetail = (value) => {
  emit('detail', value)
}

// 交付环境去重
const targetdeduplication = (policies) => {
  if (policies !== undefined && policies.length > 0) {
    const clusters = new Set() // Using Set to automatically deduplicate

    // Iterate over the array and extract clusters
    policies.forEach(item => {
      if (item.properties && item.properties.clusters) {
        item.properties.clusters.forEach(cluster => {
          clusters.add(cluster)
        })
      }
    })

    return [...clusters].join(', ')
  }
}
</script>
<style scoped>
   .operate-span-primary {
     color: var(--el-color-primary);
     cursor: pointer;
     font-weight:bold;
   }
</style>
